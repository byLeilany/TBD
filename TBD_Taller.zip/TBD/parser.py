from ply.yacc import yacc
from lexer import tokens

__all__ = ["parser", "parse_and_print"]


# Definimos una función para cada producción de la gramática

# TODO: Modificar las producciones para parsear correctamente el lenguaje

def p_expression_plus(p):
    '''
    expression : expression PLUS term
    '''
    p[0] = p[1] + p[3]


def p_expression_empty(p):
    '''
    expression :
    '''
    p[0] = 0

def p_expression_less(p):
    '''
    expression : expression LESS term
    '''
    p[0] = p[1] - p[3]

def p_term_prod(p):
    '''
    term : term PROD factor
    '''
    p[0] = p[1] * p[3]

def p_term_div(p):
    '''
    term : term DIV factor
    '''
    p[0] = p[1] / p[3]

def p_term_factor(p):
    '''
    term : factor
    '''
    p[0] = p[1]


def p_factor_neg(p):
    '''
    factor : LESS factor
    '''
    p[0] = -p[2]

def p_factor_num(p):
    '''
    factor : NUM
    '''
    p[0] = p[1]
    
def p_factor_parentesis(p):
    '''
    factor : PARA expression PARC
    '''
    p[0] = p[2]

def p_expression_term(p):
    '''
    expression : term
    '''
    p[0] = p[1]



# Manejo de errores

def p_error(p):

    if p:
        raise ParseError(
            f'Unexpected token {p.value!r} at position {p.lexpos}')
    else:
        raise ParseError(f'Unexpected end of expression')


class ParseError(Exception):
    pass


parser = yacc()


def parse_and_print(string):
    # TODO: Modificar, si es necesario, para imprimir correctamente el resultado
    # de la traducción
    parse_result = parser.parse(string)
    print(parse_result)
