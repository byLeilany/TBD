from ply.lex import lex
import sys

__all__ = ["lexer", "tokens", "tokenize"]

# Lista de tokens reconocibles por el lexer
# TODO: Agregar tokens faltantes
tokens = ['PLUS','NUM','PARA','PARC','LESS','PROD','DIV']

# Reglas para el analizador léxico

# Ignoramos espacios y tabulaciones
t_ignore = ' \t'

# Regexes para reconocer tokens simples
t_PLUS = r'\+'

# TODO: Definir regexes y/o funciones para los tokens faltantes
t_LESS = r'-'
t_PROD = r'\*'
t_PARA = r'\('
t_PARC = r'\)'
t_DIV = r'/'
def t_NUM(n):
    r'[0-9]+'
    n.value = int(n.value)
    return n 


# Ignoramos saltos de línea y llevamos registro del número de línea actual
def t_ignore_newline(t):
    r'\n+'
    t.lexer.lineno += t.value.count('\n')


# Manejo básico de errores: omitimos caracteres extraños
def t_error(t):
    print(
        f'Ignoring illegal character {t.value[0]!r} at position {t.lexpos}', file=sys.stderr)
    t.lexer.skip(1)


# Construimos el lexer
lexer = lex()


# Aplicamos el lexer e imprimimos una lista de tokens
def tokenize_and_print(string):
    lexer.input(string)
    print(list(map(lambda token: (token.type, token.value), lexer)))
